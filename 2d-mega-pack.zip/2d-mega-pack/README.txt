-- INSTRUCTIONS --

This is a collection of 2D sprites, scripts and sounds to use in your games.

Many of the elements are used in the "2D Platformer" and "PONG" courses available on the Brackeys YouTube channel.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)